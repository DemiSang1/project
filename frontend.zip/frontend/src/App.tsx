import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './index.css';

interface ImageData {
  t: string;
  f: string;
}

interface FormData {
  title: string;
  desc: string;
  x: string;
  y: string;
  m: string;
  imgs: ImageData[];
}

interface ItemInfo {
  [key: string]: any;
}

interface DBItem {
  _id: string;
  title: string;
  desc: string;
  x: number;
  y: number;
  m: number;
  items: string[];
  info?: ItemInfo[];
}

interface ImageViewerState {
  isOpen: boolean;
  images: string[];
  currentIndex: number;
}

const App: React.FC = () => {
  const [items, setItems] = useState<DBItem[]>([]);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [formData, setFormData] = useState<FormData>({
    title: '',
    desc: '',
    x: '',
    y: '',
    m: '',
    imgs: [],
  });
  const [previewImages, setPreviewImages] = useState<string[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const [imageViewer, setImageViewer] = useState<ImageViewerState>({
    isOpen: false,
    images: [],
    currentIndex: 0,
  });

  const openImageViewer = (images: string[], index: number = 0) => {
    setImageViewer({
      isOpen: true,
      images,
      currentIndex: index,
    });
  };

  const closeImageViewer = () => {
    setImageViewer({
      isOpen: false,
      images: [],
      currentIndex: 0,
    });
  };

  const goToNextImage = () => {
    setImageViewer(prev => ({
      ...prev,
      currentIndex: (prev.currentIndex + 1) % prev.images.length,
    }));
  };

  const goToPrevImage = () => {
    setImageViewer(prev => ({
      ...prev,
      currentIndex: (prev.currentIndex - 1 + prev.images.length) % prev.images.length,
    }));
  };

  const fetchItems = async () => {
    try {
      const response = await axios.post<{ state: number; items: DBItem[] }>('http://194.67.91.84/api', {
        type: 'getItems',
      });
      setItems(response.data.items);
    } catch (error) {
      console.error('Error fetching items:', error);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;

    const files = e.target.files;
    const newPreviewImages: string[] = [];
    const newImages: ImageData[] = [];

    Array.from(files).forEach((file) => {
      const reader = new FileReader();

      reader.onload = (event) => {
        if (!event.target?.result) return;

        const result = event.target.result as string;
        newPreviewImages.push(result);
        newImages.push({
          t: '.' + file.name.split('.').pop() || '',
          f: result,
        });

        if (newPreviewImages.length === files.length) {
          setPreviewImages([...previewImages, ...newPreviewImages]);
          setFormData({
            ...formData,
            imgs: [...formData.imgs, ...newImages],
          });
        }
      };

      reader.readAsDataURL(file);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await axios.post<{
        state: number;
        _id: string;
        items: string[];
        info: ItemInfo[];
      }>('http://194.67.91.84/api/upload', {
        ...formData,
        x: parseFloat(formData.x),
        y: parseFloat(formData.y),
        m: parseFloat(formData.m),
      });

      if (response.data.state === 1) {
        setFormData({
          title: '',
          desc: '',
          x: '',
          y: '',
          m: '',
          imgs: [],
        });
        setPreviewImages([]);
        setIsModalOpen(false);
        fetchItems();
      }
    } catch (error) {
      console.error('Error uploading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await axios.post<{ state: number }>('http://194.67.91.84/api', {
        type: 'delItem',
        body: { id },
      });
      fetchItems();
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  const handleJoin = async () => {
    if (selectedItems.length < 2) {
      alert('Выберите хотя бы 2 элемента для объединения');
      return;
    }

    try {
      const response = await axios.post<{
        state: number;
        body: {
          _id: string;
          items: string[];
          info: ItemInfo[];
          desc: string;
          title: string;
        };
      }>('http://194.67.91.84/api', {
        type: 'setJoin',
        body: { ids: selectedItems },
      });

      if (response.data.state === 1) {
        setSelectedItems([]);
        fetchItems();
      }
    } catch (error) {
      console.error('Error joining items:', error);
    }
  };

  const toggleSelectItem = (id: string) => {
    if (selectedItems.includes(id)) {
      setSelectedItems(selectedItems.filter((item) => item !== id));
    } else {
      setSelectedItems([...selectedItems, id]);
    }
  };

  return (
    <div className="app-container">
      <div className="content-wrapper">
        <h1 className="app-title"></h1>

        <div className="mb-6">
          <button
            onClick={() => setIsModalOpen(true)}
            className="btn btn-primary"
          >
            Добавить новый объект
          </button>
        </div>

        {/* Modal */}
        {isModalOpen && (
          <div className="modal-overlay">
            <div className="modal-content">
              <div className="modal-header">
                <h2>Добавить объект</h2>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="modal-close"
                >
                  ✕
                </button>
              </div>
              <form onSubmit={handleSubmit} className="modal-form">
                <div className="form-group">
                  <label>Название:</label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label>Описание:</label>
                  <textarea
                    value={formData.desc}
                    onChange={(e) => setFormData({ ...formData, desc: e.target.value })}
                    className="form-textarea"
                    rows={4}
                  />
                </div>
                <div className="form-grid">
                  <div className="form-group">
                    <label>X:</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.x}
                      onChange={(e) => setFormData({ ...formData, x: e.target.value })}
                      required
                      className="form-input"
                    />
                  </div>
                  <div className="form-group">
                    <label>Y:</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.y}
                      onChange={(e) => setFormData({ ...formData, y: e.target.value })}
                      required
                      className="form-input"
                    />
                  </div>
                  <div className="form-group">
                    <label>M:</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.m}
                      onChange={(e) => setFormData({ ...formData, m: e.target.value })}
                      required
                      className="form-input"
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label>Изображение:</label>
                  <input
                    type="file"
                    multiple
                    onChange={handleImageUpload}
                    accept="image/*"
                    required
                    className="form-file"
                  />
                </div>
                <div className="image-preview">
                  {previewImages.map((img, index) => (
                    <img
                      key={index}
                      src={img}
                      alt={`Preview ${index}`}
                      className="preview-image"
                      onClick={() => openImageViewer(previewImages, index)}
                    />
                  ))}
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="btn btn-submit"
                >
                  {loading ? 'Загрузка...' : 'Добавить'}
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Items List */}
        <div className="items-container">
          <div className="items-header">
            <h2>Список объектов</h2>
            <button
              onClick={handleJoin}
              disabled={selectedItems.length < 2}
              className="btn btn-join"
            >
              Объединить ({selectedItems.length})
            </button>
          </div>
          <div className="items-grid">
            {items.map((item) => (
              <div
                key={item._id}
                className={`item-card ${selectedItems.includes(item._id) ? 'item-card-selected' : ''}`}
              >
                <div className="item-header">
                  <h3>{item.title}</h3>
                  <div className="item-actions">
                    <button
                      onClick={() => toggleSelectItem(item._id)}
                      className="btn btn-select"
                    >
                      {selectedItems.includes(item._id) ? 'Снять' : 'Выбрать'}
                    </button>
                    <button
                      onClick={() => handleDelete(item._id)}
                      className="btn btn-delete"
                    >
                      Удалить
                    </button>
                  </div>
                </div>
                <p className="item-desc">{item.desc}</p>
                <p className="item-params">
                  Параметры: X={item.x}, Y={item.y}, M={item.m}
                </p>
                <div className="item-images">
                  {item.items.map((imgId, idx) => (
                    <img
                      key={imgId}
                      src={`http://194.67.91.84/api/${imgId}`}
                      alt={`Image ${imgId}`}
                      className="item-image"
                      onClick={() => openImageViewer(
                        item.items.map(id => `http://194.67.91.84/api/${id}`),
                        idx
                      )}
                    />
                  ))}
                </div>
                {item.info && item.info.length > 0 && (
                  <div className="item-info">
                    <h4>Информация о контуре:</h4>
                    <ul className="info-list">
                      {item.info.map((info, idx) => (
                        <li key={idx}>{JSON.stringify(info)}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
      {imageViewer.isOpen && (
        <div className="image-viewer-overlay">
          <div className="image-viewer-content">
            <button
              onClick={closeImageViewer}
              className="image-viewer-close"
            >
              ✕
            </button>
            <button
              onClick={goToPrevImage}
              className="image-viewer-nav image-viewer-prev"
            >
              ❮
            </button>
            <img
              src={imageViewer.images[imageViewer.currentIndex]}
              alt={`Image ${imageViewer.currentIndex + 1}`}
              className="image-viewer-image"
            />
            <button
              onClick={goToNextImage}
              className="image-viewer-nav image-viewer-next"
            >
              ❯
            </button>
            <div className="image-viewer-counter">
              {imageViewer.currentIndex + 1} / {imageViewer.images.length}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;